<?php
Route::group(
[
	'prefix' => LaravelLocalization::setLocale(),
	'middleware' => [ 'localeSessionRedirect', 'localizationRedirect', 'localeViewPath' ]
], function(){ //...

Route::group(['prefix' => 'admin'], function() {

   
    Route::get('another', function() { //admin/another
        return 'Another routing';
    });

  Route::get('/test', 'Dashboardcontroller@index');//admin/test
  Route::get('/dotest', 'Dashboardcontroller@dotest');//admin/dotest

});
});






?>