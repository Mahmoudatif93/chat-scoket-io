<?php

return [


  'dashboard'=> 'الرئسيه',



];




?>